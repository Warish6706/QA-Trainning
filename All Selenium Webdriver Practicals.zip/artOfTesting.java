package kcstestpackage;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class artOfTesting {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		
		WebDriver driver;
		
		System.setProperty("webdriver.chrome.driver", "E:\\\\Study Material\\\\Semester II\\\\Software Testing 629406\\\\chromedriver_win32\\\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("http://artoftesting.com/sampleSiteForSelenium.html");
		driver.findElement(By.xpath("//*[@id=\"post-1089\"]/div/div/p[4]/a")).click();
		
		Thread.sleep(3000);
		((JavascriptExecutor)driver).executeScript("");
        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
        //Will control on tab as according to index:
        driver.switchTo().window(tabs.get(0));

		
		
		driver.findElement(By.id("fname")).sendKeys("I am Warish");
		Thread.sleep(3000);
		driver.findElement(By.id("fname")).clear();
		Thread.sleep(3000);
		driver.findElement(By.id("idOfButton")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("male")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"post-1089\"]/div/div/form[2]/input[1]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id=\"post-1089\"]/div/div/form[2]/input[2]")).click();
		
		WebElement testDropDown = driver.findElement(By.id("testingDropdown"));
		Select dropdown = new Select(testDropDown);
		
		dropdown.selectByIndex(0);
		dropdown.selectByIndex(1);
		dropdown.selectByIndex(2);
		
		

		
		
		
	}

}
