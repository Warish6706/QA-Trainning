package kcstestpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToolQA {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver;
		
		System.setProperty("webdriver.chrome.driver", "E:\\\\Study Material\\\\Semester II\\\\Software Testing 629406\\\\chromedriver_win32\\\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/webtables");
		
		driver.findElement(By.id("addNewRecordButton")).click();
		driver.findElement(By.id("firstName")).sendKeys("Warish");
		Thread.sleep(2000);
		driver.findElement(By.id("lastName")).sendKeys("Kumar");
		Thread.sleep(2000);
		driver.findElement(By.id("userEmail")).sendKeys("warish@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("age")).sendKeys("90");
		Thread.sleep(2000);
		driver.findElement(By.id("salary")).sendKeys("20000");
		Thread.sleep(2000);
		driver.findElement(By.id("department")).sendKeys("QA");
		Thread.sleep(4000);
		driver.findElement(By.id("submit")).click();
		
		driver.findElement(By.xpath("//*[@id=\"edit-record-4\"]/svg/path")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("userEmail")).sendKeys("warishkumar@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("submit")).click();
		
		
		
		
		
	}

}
