package kcstestpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginLogout {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		WebDriver driver;
		
		System.setProperty("webdriver.chrome.driver", "E:\\\\Study Material\\\\Semester II\\\\Software Testing 629406\\\\chromedriver_win32\\\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php");
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a")).click();
		driver.findElement(By.id("email")).sendKeys("mumlebitre@vusra.com");
		driver.findElement(By.id("passwd")).sendKeys("Warish@123");
		driver.findElement(By.xpath("//*[@id=\"SubmitLogin\"]/span")).click();
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[1]/a/span")).click();
		driver.findElement(By.xpath("//*[@id=\"header\"]/div[2]/div/div/nav/div[2]/a")).click();
		
		
	}

}
