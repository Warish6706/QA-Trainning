package kcstestpackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class fruitselection {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		WebDriver driver;
		
		System.setProperty("webdriver.chrome.driver", "E:\\Study Material\\Semester II\\Software Testing 629406\\chromedriver_win32\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.get("http://output.jsbin.com/osebed/2");
		
		WebElement testDropDown = driver.findElement(By.id("fruits"));
		Select dropdown = new Select(testDropDown);
		
		dropdown.selectByValue("banana");
		Thread.sleep(1500);
		dropdown.selectByValue("apple");
		Thread.sleep(1500);
		dropdown.selectByValue("orange");
		Thread.sleep(1500);
		dropdown.selectByValue("grape");
		Thread.sleep(1500);
		
		dropdown.deselectAll();
	}

}
