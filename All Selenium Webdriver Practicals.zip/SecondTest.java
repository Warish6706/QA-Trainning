package kcstestpackage;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SecondTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
WebDriver driver;
		
		System.setProperty("webdriver.gecko.driver", "E:\\Study Material\\Semester II\\Software Testing 629406\\geckodriver.exe");
		
		driver = new FirefoxDriver();
		
		driver.manage().window().maximize();
		
		
		
		
		 ((JavascriptExecutor)driver).executeScript("window.open()");
	        ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
	        //Will control on tab as according to index:
	        driver.switchTo().window(tabs.get(1));
	        driver.get("https://www.facebook.com/"); 
	        driver.switchTo().window(tabs.get(0));
		

	}

}
